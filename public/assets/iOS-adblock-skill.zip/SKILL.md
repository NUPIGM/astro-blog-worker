---
name: iOS 去广告重写插件编写
description: 为 Surge / Loon / Quantumult X 三款 iOS 代理客户端生成去广告与界面裁剪插件（.sgmodule / .plugin / .conf）及配套脚本。当用户给出目标 App 版本号与 .har 抓包记录，需要定位广告请求、或按字段隐藏对应界面与按钮（关掉入口 / 移除推广位 / 裁剪模块），判断拦截方式（域名拒绝 / 资源 Mock / JSON 字段改写 / 脚本处理），并按需求边界与验收清单确保隐藏范围覆盖完整时使用。触发词：去广告插件、sgmodule、Loon plugin、QuanX rewrite、har 抓包分析、开屏广告、信息流广告、隐藏按钮、隐藏入口、关掉某个功能、字段隐藏、界面裁剪、按字段隐藏、App 净化、Surge 模块生成。
---

# iOS 三端响应改写生成器（去广告 / 界面裁剪）

## 0. 这个 Skill 产出什么

输入：**一个 App 的版本号 + 一份 .har 抓包记录**。  
产出：三端可安装的插件文件 + 共享脚本 + 一份说明。裁剪类需求另附**覆盖矩阵**与**未实现清单**（§17.6）。

```
<AppName>-AdBlock/
├── Surge/<AppName>.AdBlock.sgmodule
├── Loon/<AppName>.AdBlock.plugin
├── QuanX/<AppName>.AdBlock.conf
├── scripts/<appname>-<场景>.js        # 三端共用同一份
└── README.md                          # 安装 / 停用 / 失效排查
```

每个 App 一套上述目录；**跨 App 的规则索引是另一份文件**（`registry.md`，见 §16），按插件库而非按 App 存放。

核心原则四条，违反任一条即为不合格交付：

1. **每条规则必须在 HAR 里有证据**。没有在抓包里出现过的 URL pattern，不许写进插件。
2. **能声明式解决就不写脚本**。脚本要多一次 body 缓冲、多一份托管、多一处失效点。
3. **绝不误杀主业务**。宁可少拦，不可让 App 白屏、灰块、登录失败。
4. **要么全覆盖，要么明说做不到**。同一字段的多个渲染面必须一起处理；技术上不可实现的，必须在交付里列出并说明原因——**半覆盖比不覆盖更糟**，因为用户会以为已经好了。

**目录**

| 章节  | 内容                               | 什么时候看                |
| --- | -------------------------------- | -------------------- |
| §1  | 触发条件                             | 判断该不该用本 Skill        |
| §2  | 硬性输入 + 版本门槛                      | 开工前收集信息              |
| §3  | 执行流程 Step 0–7                    | 主流程                  |
| §4  | 判定决策树                            | 决定用哪种拦截手段            |
| §5  | jq 取证手册（含时序分析 / 完整性校验）           | 分析 HAR               |
| §6  | 三端语法对照 + 离线兜底 + 优先级与内存预算         | 翻译规则 / 排障「没生效」       |
| §7  | 脚本骨架 + 四个工程细节（幂等 / 缓存 / 分页 / 流式） | 需要写脚本时               |
| §8  | 输出规范 + 验证闭环 + 隐私脱敏               | 组装交付物 / 教用户自证        |
| §9  | 自检清单                             | 交付前必过                |
| §10 | 失效陷阱 15 条                        | 排查 / 预检              |
| §11 | 示例 A：信息流数组（要脚本）                  | 学写脚本方案               |
| §12 | 示例 B：开屏广告（不要脚本）                  | 学声明式方案               |
| §13 | 官方文档索引 + 抓取规程                    | 核语法（本 Skill 不存快照，现查） |
| §14 | 边界                               | 判断需求是否越界             |
| §15 | 复核与维护（规则编号 / 体检脚本 / 失效归因）        | 每次升级后体检              |
| §16 | 规则索引（跨 App 反查，`registry.md`）     | 用户说「又有广告了」           |
| §17 | 界面裁剪：需求边界 / 覆盖矩阵 / 验收标准          | 用户要隐藏某个入口            |
| §18 | 快速回顾                             | 动手前扫一眼               |

---

## 1. 触发条件

### 1.1 该用

- 用户说「帮 X App 写个去广告插件 / 规则 / 模块」
- **用户根据抓包提出「隐藏某个字段对应的界面 / 按钮 / 入口」「关掉某个模块」** → 这是**界面裁剪**，不是去广告。先出 §17.2 的隐藏范围清单并让用户确认，再动手；漏掉一个渲染面，用户就会说「这里还有」
- 用户给了 `.har` 文件或抓包截图，问「这条请求怎么拦」
- **用户抱怨「X 又有广告了 / 广告回来了 / 插件失效了」** → **先查 §16 索引，不要一上来就要 HAR**。索引里大概率已经有这个 App 的规则 ID 与失效信号，能直接给出归因；只有归因指向"接口变了"时才需要重抓
- 用户已有插件在新版 App 上失效，要按新版本重做（**先查索引确认是否已有记录**，再决定要不要全量重抓）
- 用户要把一套现有规则从 A 客户端迁移到 B 客户端

> 最后两条的顺序很重要：**「抱怨」触发的是检索，不是重做。** 全文流程最贵的环节是重抓 HAR 与重新画像，索引存在的意义就是让这两步只在必要时发生。

### 1.2 不该用

- 只写纯域名分流规则（`DOMAIN-SUFFIX,...,REJECT`）而不涉及 HTTP 改写 → 直接给规则即可
- 目标是绕过会员 / 付费 / 授权校验 / 风控 → 见 §14，拒绝
- 没有 HAR，只有口头描述「有个广告弹窗」 → 先让用户抓包，不要凭猜测编 pattern

---

## 2. 硬性输入（缺一不可）

开工前必须凑齐下表中标 **必须** 的项。缺项就问，但**一次问完，最多问 3 个问题**。

| 项                                 | 必须        | 为什么必须要                                                                                 |
| --------------------------------- | --------- | -------------------------------------------------------------------------------------- |
| App 名称 + 版本号（含 Build）             | ✅         | 广告 SDK 的接口路径、字段名随版本变。7.12.0 的 `data.items`，7.13.0 可能变成 `data.cards`。不锚定版本 = 交一份注定过期的东西 |
| `.har` 抓包文件                       | ✅         | 唯一可信的证据源。所有 pattern 从这里取，不从记忆里取                                                        |
| 抓包客户端 + 版本                        | ✅         | 决定语法。见下方「版本门槛」                                                                         |
| 目标客户端（Surge / Loon / QuanX / 全都要） | ✅         | 三端语法不同，输出范围影响工作量                                                                       |
| 脚本托管方式                            | ⚠️ 有脚本时必问 | 见 §2.2。没有可托管地址，就必须改走声明式方案                                                              |
| iOS 版本、设备型号                       | ○         | 排查「是规则没生效，还是系统行为变了」时有用                                                                 |
| 广告形态（开屏 / 信息流 / 悬浮 / banner）      | ○         | 帮助在 HAR 里定向筛选                                                                          |

### 2.1 采集模板（可直接发给用户）

```
为了按版本精确生成，需要你提供 4 项信息：

1. App 名称 + 版本号（设置→关于 里的完整号，如 7.12.0 (7120)）
2. .har 抓包文件（抓包时务必开启「保存响应体」，否则拿不到 body）
   抓取建议：只做「打开 App → 触发广告 → 关闭 App」这一轮，噪声最少
3. 你用的抓包客户端及版本（Surge 5.x / Loon 3.5.1(983) / QuanX 1.4.x）
4. 要生成哪几端？Surge / Loon / QuanX / 三端都要
```

### 2.2 脚本托管：先问清楚，再决定技术路线

这一条最容易被忽略，却直接决定方案能不能用。

| 用户情况                         | 技术路线                                                                                                     |
| ---------------------------- | -------------------------------------------------------------------------------------------------------- |
| 有自己的 CDN / GitHub Raw 可放 .js | 可以走脚本路线，三端引用同一个 URL                                                                                      |
| 没有托管，但用 Surge / Loon         | 优先声明式：Surge `[Body Rewrite] http-response-jq`、`[Map Local]`；Loon `response.json.replace` / `reject_dict` |
| 没有托管，且用 QuanX                | QuanX 无原生 JSON 动作 → 只能用 `response-body` 正则替换；正则不稳时，退化为「拦截整个广告接口 + `reject-dict`」                         |
| 用户能接受把脚本放进本地目录               | Surge 支持相对路径（相对配置文件目录）；QuanX 支持 `Scripts/` 下的文件名；Loon 支持本地文件                                             |

> 判断口径：**能不用脚本就不用脚本**。脚本方案的下限是「用户得会传文件」，声明式方案的下限只是「复制一段文本」。

### 2.3 版本门槛：为什么版本号是硬性输入

三端都有「新特性只在某个 build 之后可用」的情况，写错就是装上不报错、但完全不起作用：

| 能力                                                       | 客户端门槛                          |
| -------------------------------------------------------- | ------------------------------ |
| Surge `[Body Rewrite]` 正则改写                              | Surge iOS 5.10.0+ / Mac 5.6.0+ |
| Surge `[Body Rewrite]` jq 改写                             | Surge iOS 5.14.0+ / Mac 5.9.0+ |
| Surge `[Map Local]` `data-type=tiny-gif / text / base64` | Surge iOS 5.9.1+ / Mac 5.5.1+  |
| Surge `#!arguments` 参数表                                  | Surge Mac 5.5.0+               |
| Surge `#!requirement`                                    | Surge iOS 5.10.0+ / Mac 5.6.0+ |
| Loon 新 Script 语法 `response if ... then script(...)`      | Loon 3.5.1 (983)+              |
| Loon `[Argument]` 参数段                                    | Loon Build 733+                |
| QuanX 18 种 rewrite 动作                                    | 长期稳定，无版本门槛                     |

**做法**：能在插件里表达门槛的就表达出来（Surge 用 `#!requirement=CORE_VERSION>=…`，Loon 用 `#!loon_version = …`），不能表达的就写进 README 的「适用版本」。

> ⚠️ **`CORE_VERSION` 是个陷阱，它表达不了「中间版本」。**  
> 官方映射：`20` = Mac 5.6.0 / iOS 5.10.0（Body Rewrite、Inline Map Local）；`22` = Mac 5.7.0 / iOS 5.11.0（Smart Group）。  
> 自 Mac 6.8.0 / iOS 5.21.0 起才改为 `major*1000000 + minor*1000 + patch`（6.8.0 → `6008000`）。  
> 也就是说 iOS 5.14.0 这个版本**没有对应的 CORE_VERSION 档位**。  
> 所以 `#!requirement=CORE_VERSION>=20` 只能保证「支持 Body Rewrite」，**保证不了 jq 改写（iOS 5.14.0+）**。  
> → jq 方案的版本要求必须额外写进 README；或者直接用 `[Script]`，绕开整个门槛问题。

---

## 3. 执行流程

### Step 0 — 清点输入，锁定基线

1. 确认 App 版本号，写进本轮工作记录的标题，例如 `DemoApp 7.12.0 @ 2026-11-01`。
2. 校验 HAR 是否可用：

```bash
jq '.log.entries | length' target.har
```

- 结果为 0 或报错 → 文件不是合法 HAR，让用户重导。
- 结果 > 0 但 `response.content.text` 普遍为 `null` → 抓包时没开「保存响应体」，让用户重抓。**这一步没通过不要往下走**，后面所有改写都依赖 body。

1. 若同一 App 有多个版本的 HAR，先做 §5.6 的版本对比，找出「新版新增的广告接口」——这通常就是失效的根因。

### Step 0.5 — 需求定界（隐藏类需求必做）

先判断这次到底是「去广告」还是「界面裁剪」。两者看着像，失败方式却完全不同：

|      | 去广告        | 界面裁剪                  |
| ---- | ---------- | --------------------- |
| 成功标准 | 广告看不见了     | 用户指的入口全消失，**而且别处也没有** |
| 典型失败 | 误杀主业务      | **漏掉渲染面**（用户："这里还有"）  |
| 关键动作 | 判定拦截手段（§4） | 枚举覆盖矩阵（§17.3）         |
| 前置产出 | 候选请求表      | **隐藏范围清单**（需用户确认）     |

隐藏类需求在取证之前，必须先产出「隐藏范围清单」并让用户点头。**没有清单就开始写规则，等于赌自己记得全**——而"记得全"这件事，从来不成立。

完整方法见 **§17**（需求边界 / 覆盖矩阵 / 验收标准）。去广告类需求可跳过本节。

### Step 1 — 用 jq 给 HAR 做「广告请求画像」

目标：把上百条请求收敛成 3~8 条候选。按 §5 的配方依次执行：

1. §5.1 主机分布 → 找出可疑的独立广告域名
2. §5.2 关键词筛选 → 找出 splash / ad / banner / promote / launch 相关路径
3. §5.3 结构分组 → 按 mimeType 区分「JSON 配置」还是「图片/视频素材」
4. §5.4 导出可疑 body → 人眼确认里面到底是不是广告
5. §5.5 键路径枚举 → 定位到具体字段

**收敛标准**：能回答出「这个 App 的广告由哪几条请求驱动」。答不出来就继续筛，不要开始写规则。

### Step 2 — 分类，选手段

用 §4 决策树。把每条候选请求标注为一种手段，形成一张表：

| 请求                                  | 形态           | 手段           | 是否需脚本 |
| ----------------------------------- | ------------ | ------------ | ----- |
| `api.demoapp.com/v1/feed/list`      | JSON，数组内含推广项 | 脚本过滤数组       | 是     |
| `conf.demoapp.com/v2/launch/config` | JSON，开关字段    | jq / json 改写 | 否     |
| `img.demoapp.com/splash/*.jpg`      | 图片素材         | Mock 1px     | 否     |
| `splash.demoapp.com/v1/get`         | 独立广告接口       | 整请求拒绝        | 否     |

这张表是后面所有产出的骨架。

### Step 3 — 查官方文档核对语法

**禁止凭记忆写语法。** 每端至少打开本节对应文档 1 次，确认：

- 段名大小写（`[MITM]` / `[Mitm]` / `[mitm]`）
- 动作关键字拼写（`reject-img` 还是 `reject_img`）
- 该动作是否需要 MITM
- 该动作的版本门槛

文档索引见 §13。核对后，在 README 里注明「语法依据：<文档页 URL>」。

### Step 4 — 写脚本（仅在需要时）

- 用 §7 的三端通用骨架，**一份脚本服务三端**，不要写三份。
- 所有 `JSON.parse` 必须包 `try/catch`，失败就 `$done({})` 原样放行。
- 所有分支都必须调用 `$done`，包括 `!body` 的早退分支。
- 只删/改与广告相关的字段，**不碰登录态、订单、支付、风控字段**。  
  |  |  |  |  
  | --- | --- | --- |
- 字段访问用防御式写法：`(obj.data && obj.data.items) || []`，不要链式硬取。

### Step 5 — 组装插件文件

用 §6 的对照表把同一套逻辑翻译成三种语法。要求：

- 三端的 URL 正则**逐字符一致**，方便日后同步维护
- MITM hostname 覆盖所有 pattern 的 host，且用通配符收敛（`*.demoapp.com` 优于逐个列举）
- 不需要 MITM 的域名不要放进去（会白白增加握手失败面）

### Step 6 — 自检

逐条过 §9 清单。任何一条不过，回到对应步骤改，不要「先交付再说」。

### Step 7 — 交付

交付物用 §8 的目录结构。README 必须含四节：

1. 适用版本（App 版本 + 客户端版本）
2. 安装步骤（分三端写）
3. 如何停用（模块开关 / 注释掉哪一行）
4. 失效了怎么自查（看 MITM 是否绿锁、看 pattern 是否还命中、重新抓包对比）

**回复用户时必须说明三件事**：命中的证据条数、每条规则用了什么手段、已知的失效风险。

---

## 4. 判定决策树

```
抓到的请求
├─ 用户要的是「某个字段对应的界面 / 按钮不要出现」？
│   └─ 是 → 界面裁剪：先按 §17.2 定界、§17.3 找全渲染面，再回到本树选手段
├─ 是图片 / 视频 / gif 素材？
│   └─ 是 → 素材 Mock（1px 图 / 空视频）
│            ├─ 该路径只服务广告 → 可整路径拒绝
│            └─ 该路径也服务业务 → 只 Mock，不要 reject（避免 404 触发重试）
├─ 响应是 JSON？
│   ├─ 广告 = 某个固定键（开关 / 配置）→ 声明式：jq 改写 或 json.replace
│   ├─ 广告 = 数组里带标记的元素 → 必须脚本（原生动作不支持条件过滤数组）
│   └─ 广告 = 整个响应体就是广告数据 → 直接 reject-dict（返回空 JSON，防解析崩溃）
├─ 响应是 HTML / JS 直出（服务端渲染的广告位）？
│   ├─ 可用正则稳定匹配 → body 正则替换
│   └─ 结构不稳定 → 注入 `<style>` 隐藏（脚本改 body，脆弱，需注明）
├─ 请求本身就是「上报 / 曝光 / 埋点」？
│   └─ 直接拒绝，风控影响最小，收益是省流量
└─ protobuf / 二进制 / 加密 body？
    ├─ 能只在请求侧做手脚（改 query、改 header、改 UA）→ 做
    └─ 不能 → 明确告知「该请求不可安全改写」，不硬做
```

**三个反直觉的点，值得记住：**

- **「拒绝」比「Mock」风险高。** reject 返回 404/无内容，App 可能判定网络异常并重试、甚至降级到备用广告源；返回一个结构正确的空 JSON（`{}` / `[]`）或 1px 图，App 会安静地当成"没有广告"。
- **「整域名拒绝」是最后手段。** 广告域名常与统计、CDN、图片服务共用，`DOMAIN-SUFFIX` 一刀切下来，副作用往往在几天后才被用户发现（图片加载不出、消息推送丢失）。
- **「隐藏入口」不等于「关闭功能」。** 入口删掉了，深链、推送、搜索结果仍可能把用户送进同一个页面。用户说"我不想要这个"，通常指功能而不是按钮——这正是 §17.2 第一问存在的理由。

---

## 5. jq 取证手册

以下配方均以 `target.har` 为输入。执行前先 `jq --version`（需 ≥1.6；本节配方在 jq 1.8.1 上实测通过）。

> 用法约定：`target.har` 是抓包文件，`feed.json` 是 §5.4 导出的**单条响应体**。  
> 文中的 `12` 是示例索引，实际用 §5.4 第一条命令查出来的数字替换。

### 5.1 主机分布：谁在说话

```bash
jq -r '[.log.entries[].request.url
        | try capture("^https?://(?<h>[^/]+)").h catch "?"]
       | group_by(.) | map({h: .[0], n: length})
       | sort_by(-.n) | .[] | "\(.n)\t\(.h)"' target.har
```

读法：条数少但域名陌生（`adx-`、`-ads`、`track`、`promote`、`gdt`、`pangle`、`csj`）的，就是重点嫌疑。

### 5.2 关键词筛候选

```bash
jq -r '.log.entries[]
  | select(.request.url | test("ad|ads|adv|splash|launch|banner|popup|promote|sponsor|market|float|interstitial"; "i"))
  | [.response.status,
     (.response.content.mimeType // "-"),
     (.response.content.size // 0 | tostring),
     .request.url] | @tsv' target.har | sort -u
```

### 5.3 按响应类型分组，区分「配置」和「素材」

```bash
jq -r '.log.entries[]
  | [(.response.content.mimeType // "unknown"),
     (.response.content.size // 0 | tostring),
     .request.url] | @tsv' target.har \
| awk -F'\t' '{print $1}' | sort | uniq -c | sort -rn
```

- `application/json` → 走 JSON 改写路线
- `image/*` `video/*` → 走素材 Mock 路线
- `text/html` → 走 body 替换路线

单看 JSON：

```bash
jq -r '.log.entries[]
  | select((.response.content.mimeType // "") | test("json"; "i"))
  | [.response.status, (.response.content.size // 0 | tostring), .request.url] | @tsv' target.har
```

### 5.4 导出某条请求的响应体（含 base64 解码）

先取索引：

```bash
jq -r '.log.entries | to_entries[]
  | select(.value.request.url | test("feed/list"))
  | "\(.key)\t\(.value.request.url)"' target.har
```

再按索引导出：

```bash
jq -r '.log.entries[12].response.content
  | if .encoding == "base64" then (.text | @base64d) else (.text // "") end' \
  target.har > feed.json
```

> **注意**：`@base64d` 对二进制（图片、protobuf、gzip 残留）**不会报错**，而是把非法字节静默替换成 `�`（U+FFFD）。所以判断标准不是「有没有报错」，而是「导出的文件里有没有成片乱码」。一旦出现乱码，说明这不是文本，不要解码，保留原始 base64：  
> `jq -r '.log.entries[12].response.content.text' target.har > feed.b64`

### 5.5 枚举键路径，定位到字段

```bash
jq -r '(if type=="string" then fromjson else . end)
       | [paths(scalars)] | .[] | map(tostring) | join(".")' feed.json | head -60
```

只关心广告相关：

```bash
jq -r '(if type=="string" then fromjson else . end)
       | [paths(scalars)] | .[] | map(tostring) | join(".")
       | select(test("ad|promote|splash|banner|sponsor|market"; "i"))' feed.json
```


看某字段的取值分布（判断是不是"广告标记位"）：

```bash
jq -r '(if type=="string" then fromjson else . end)
       | [.. | objects | .type? // empty]
       | group_by(.) | map({v: .[0], n: length})' feed.json
```

> 开头那个 `(if type=="string" then fromjson else . end)` 是必需的兼容写法，不是装饰。
> 原因见 §5.8 第 1 条：**`feed.json` 已经是解析好的 JSON 对象，再套 `fromjson` 会直接报错**。加上这一层判断，无论文件里存的是「JSON 字符串字面量」还是「JSON 对象」都能跑通。

### 5.6 版本对比：找出新版新增的广告接口

```bash
jq -r '[.log.entries[].request.url | sub("\\?.*$"; "")] | unique | .[]' old.har | sort > old.txt
jq -r '[.log.entries[].request.url | sub("\\?.*$"; "")] | unique | .[]' new.har | sort > new.txt
comm -13 old.txt new.txt     # 新版新增
comm -23 old.txt new.txt     # 新版移除（旧规则可删）
```

### 5.7 验证 pattern 是否真能命中（写规则前必做）

把准备写进插件的正则，先在 HAR 上跑一遍，命中数必须 > 0：

```bash
jq -r --arg re '^https?://api\.demoapp\.com/v1/feed/list' \
  '[.log.entries[] | select(.request.url | test($re))] | length' target.har
```

**命中数 0 就说明正则写错了**（多见于 `.` 未转义、`?` 被当成量词、大小写不符）。这一步能挡掉绝大多数「装上没反应」的返工。

### 5.8 写规则时最容易踩的 jq 坑

| 坑 | 表现 | 正解 |
|---|---|---|
| `fromjson` 用在已经是 JSON 的文件上 | `only strings can be parsed` | 用 `(if type=="string" then fromjson else . end)`，或直接去掉 `fromjson` |
| `paths(scalars)` 忘记包 `[ ]` | 输出多行但无法 `join` | `[paths(scalars)] \| .[] \| map(tostring) \| join(".")` |
| `//` 与 `or` 混用优先级 | 过滤条件恒真/恒假 | 加括号：`select((.type // "") == "ad")` |
| `@base64d` 处理二进制 | 不报错，但输出成片 `�` | 别解码，保留 base64 交给人眼/hexdump |
| `.response.content.size` 为 null | `tostring` 后是 `"null"` | `(.size // 0 \| tostring)` |

### 5.9 时序分析：用「冷启动窗口」定位开屏类广告

开屏广告和信息流广告的取证位置不同：它不在「某个页面」里，而在「启动后的前几秒」里。靠关键词筛会漏，靠时序筛才准。

```bash
jq -r '.log.entries
  | sort_by(.startedDateTime // "")
  | .[0:20][]
  | [((.startedDateTime // "-")[11:23]),
     ((.time // 0) | floor | tostring),
     (.response.status | tostring),
     (.response.content.mimeType // "-"),
     .request.url] | @tsv' target.har
```

实测输出（示例 B 那套开屏流程）：

```
10:21:03.114  180  200  application/json  https://conf.demoapp.com/v2/launch/config
10:21:03.302   95  200  application/json  https://splash.demoapp.com/v1/get?slot=open
10:21:03.640  410  200  image/jpeg        https://img.demoapp.com/splash/0912.jpg
10:21:05.100  620  200  application/json  https://api.demoapp.com/v1/feed/list?page=1
```

**读法：找「链」，不是找「点」。**

| 环 | 特征 | 含义 |
|---|---|---|
| 第 1 环 | 小 JSON（< 1KB），路径含 config / launch / init | 开关与配置 |
| 第 2 环 | JSON，含素材 URL 或 `ad_id` | 广告位下发 |
| 第 3 环 | image / video，几十 KB ~ 几 MB | 素材 |

- 链条成立 → 三环都要处理（§12 已证明只拦一环无效）
- **链条不成立**（只有第 3 环，没有前两环）→ 配置走了本地缓存，此时拦素材也没用，因为 App 读的是本机缓存（处置见 §7.2）

**两个判据，避免过度筛选：**

- `time > 300ms` 且排在首屏请求之前 → 通常在阻塞渲染的关键路径上，广告往往就在这条
- 链内相邻请求间隔 < 500ms、且全部落在启动后 3 秒内 → 基本可确认属于同一套广告流程

> 防御式写法的原因：HAR 里 `startedDateTime` / `time` 可能缺失（部分工具导出时省略），直接对 `null` 做切片或算术会报 `number required`。所以命令里加了 `// ""` 和 `// 0`——缺字段的条目会排在最前且时间显示为 0，正好提示你这一条数据不完整。

### 5.10 数据完整性校验（写规则前的最后一道闸）

§5.7 验证的是「pattern 能否命中」，本节验证的是「命中之后有没有东西可改」。两者都过了才动手。

```bash
# 1) 抓到了但没存 body —— 对它写改写规则 100% 无效
jq -r '.log.entries[]
  | select(.response.content.text == null)
  | .request.url' target.har

# 2) size 与 text 长度严重不符 —— 可能被截断
jq -r '.log.entries[]
  | select(.response.content.text != null)
  | select((.response.content.size // 0) > 0)
  | select((((.response.content.text | length) as $l
             | ((.response.content.size - $l) | fabs) / .response.content.size)) > 0.5)
  | .request.url' target.har
```

|  |  |  |
| --- | --- | --- |
第二条依赖 `fabs`（jq 1.6+）。若你的 jq 没有，把 `| fabs` 换成 `| if . < 0 then -. else . end`。

四类「看起来正常、实际不能改」的 body：

| 现象 | 真实原因 | 处置 |
|---|---|---|
| `text` 为 `null` | 抓包未开「保存响应体」 | 重抓（Step 0 已拦） |
| `text` 有值但末尾截断 | 抓包工具单条上限 | 只改头部字段，或换工具重抓 |
| `encoding: base64` 且解码首字节是 `1f 8b` | gzip 未还原 | 不要手写解压，交给脚本侧（三端交付的都是解压后字符串） |
| `content-type: text/event-stream` | 流式响应，没有完整 body | 见 §7.4，不要试图改 body |

**为什么值得单独查一遍**：`text == null` 的条目在 §5.7 里会正常命中（URL 匹配成功），但写进插件后百分之百无效。这是「规则命中却不生效」最隐蔽的成因——它骗过了 grep，也骗过了肉眼。

---

## 6. 三端语法对照

### 6.1 文件与元信息

| | Surge | Loon | Quantumult X |
|---|---|---|---|
| 扩展名 | `.sgmodule` | `.plugin` | `.conf`（片段，粘贴进主配置） |
| 名称 | `#!name=xxx` | `#!name = xxx` | 注释 `;` 或 `#` |
| 描述 | `#!desc=xxx` | `#!desc = xxx` | 注释 |
| 平台限制 | `#!system=ios` | `#!system = iOS` | — |
| 分类 | `#!category=去广告`（社区通行，非手册条目） | `#!tag = 去广告` | — |
| 作者 | `#!author=xxx`（社区通行） | `#!author = xxx` | — |
| 版本门槛 | `#!requirement=CORE_VERSION>=20` | `#!loon_version = 3.5.1(983)` | — |
| 参数表 | `#!arguments=name:默认值` + `{{{name}}}` | `[Argument]` 段 + `${name}` | — |
| MITM 段名 | `[MITM]` | `[Mitm]` | `[mitm]` |
| MITM 追加 | `hostname = %APPEND% a.com` | `hostname = a.com` | `hostname = a.com` |
| 脚本段 | `[Script]` | `[Script]` | `[rewrite_local]` 行内声明 |

### 6.2 动作对照

| 目的 | Surge | Loon | QuanX |
|---|---|---|---|
| 拒绝请求 | `^re _ reject`（`[URL Rewrite]`） | 新：`request if ${url} ~= /re/ then reject(403)`<br>旧：`^re url reject` | `^re url reject` |
| 返回空 JSON 对象 | `[Map Local] ^re data-type=text data="{}"` | `reject_dict(200)` / 旧 `reject-dict` | `^re url reject-dict` |
| 返回空 JSON 数组 | `[Map Local] ^re data-type=text data="[]"` | `reject_array(200)` / 旧 `reject-array` | `^re url reject-array` |
| 返回 1px 图 | `[Map Local] ^re data-type=tiny-gif` | `reject_img(200)` / 旧 `reject-img` | `^re url reject-img` |
| 302 跳转 | `[URL Rewrite] ^re https://new 302` | `redirect(302, "https://new")` | `^re url 302 https://new` |
| 改请求头 | `[Header Rewrite]`<br>`http-request ^re header-del X-Ad` | `request.header.del("X-Ad")` | `^re url request-header (\r\n)X-Ad:.+(\r\n) request-header $1` |
| 改响应体（脚本） | `[Script]`<br>`x = type=http-response,pattern=^re,requires-body=true,script-path=URL` | `[Script]`<br>`http-response ^re script-path=URL, requires-body=true, tag=xxx` | `[rewrite_local]`<br>`^re url script-response-body URL` |
| 改 JSON（原生） | `[Body Rewrite]`<br>`http-response-jq ^re '.a.b = false'` | `response.json.replace("a.b", false)`<br>`response.json.delete("a.b")` | 无 → 用 `response-body` 正则 |
| 正则替换 body | `[Body Rewrite]`<br>`http-response ^re 匹配 替换` | `response.body.replace(/匹配/, "替换")` | `^re url response-body 匹配 response-body 替换` |

### 6.3 脚本 API 对照

| | Surge | Loon | QuanX |
|---|---|---|---|
| 请求 | `$request.url` / `.method` / `.headers` | 同 | 同 |
| 响应 | `$response.status` / `.headers` / `.body` | 同 | 同 |
| 结束 | `$done({ body })` | 同 | 同 |
| 通知 | `$notification.post(t, s, b)` | 同 | `$notify(t, s, b)` |
| 持久化 | `$persistentStore.read/write` | 同 | `$prefs.valueForKey/setValueForKey` |
| 网络请求 | `$httpClient.get/post` | 同 | `$task.fetch` |
| 参数 | `$argument` | `$argument` | 无（用 URL query 传） |

> 三端共同子集只有 `$request` / `$response` / `$done`。**只用共同子集写脚本**，天然三端通用；一旦引入 `$notify` 或 `$persistentStore`，就必须在骨架里做适配（见 §7）。

### 6.4 Loon 新旧语法怎么选

| 用户 Loon 版本 | 用哪套 | 理由 |
|---|---|---|
| < 3.5.1 (983) | 旧语法 `http-response ^re script-path=..., requires-body=true` | 新语法不认 |
| ≥ 3.5.1 (983) | 旧语法仍可用；需要「多条件组合」时用新语法 | 新语法支持 `${url}` `~=` `&&` `\|\|`、正则捕获、`[Argument]` 参数，表现力强得多 |

旧语法兼容面更广，默认给旧的；只有当用户明确需要按 header / 状态码组合条件时，才升级到新语法并写 `#!loon_version`。

### 6.5 离线兜底边界（本节能独立撑到什么程度）

本 Skill 刻意不存文档快照（见 §13），所以本节是**唯一保底**。必须清楚它的能力边界：

| 只靠本节就能做 | 必须查官方文档确认 |
|---|---|
| 三端基本动作：拒绝 / 重定向 / 1px 图 / 空 JSON / 改 header | 某动作的**准确参数名与顺序** |
| 脚本骨架、三端 API 共同子集（`$request`/`$response`/`$done`） | 新版本新增的动作（如 Loon `reject_video`） |
| 段名大小写（`[MITM]`/`[Mitm]`/`[mitm]`） | 任何 **build 号 / iOS 版本门槛** |
| 文件结构、元信息骨架、MITM 追加写法 | `[Argument]` 的 type 约束、取值合法性 |

**文档全部不可达时的处置**：

1. 只产出上表左列覆盖范围内的规则 + 脚本方案
2. 在 README 显式写「⚠️ 语法未与官方文档核对，仅在 <客户端版本> 待验证」
3. 查不到官方文档时**不是**凭记忆补，而是按 §13.2 判定：有实例 → 保留 + 标 C 级 + 留后路；无实例 → 禁用。

> 反过来也成立：如果一条规则需要查文档才能确定，说明它**不是**常规写法，写进插件后就多了一个版本风险点。这时优先考虑用脚本实现（脚本走共同子集，不受客户端语法演进影响）。

### 6.6 优先级与冲突：为什么规则写了却不生效

同一 URL 被多条规则命中时，胜负由**处理阶段**决定，不由书写顺序决定。这是排障时最该先想清楚的一件事。

**Surge 的阶段顺序**（请求→响应）：

```
① MITM 解密        hostname 不在列表 → 后续环节全部看不到这条流量
② [URL Rewrite]    改 URL / 拒绝
③ [Map Local]      命中即本地生成响应，不再发往上游
④ ── 上游响应返回 ──
⑤ [Body Rewrite]   先改 body
⑥ [Script] http-response  拿到的是「已改写」的 body
⑦ [Header Rewrite] 改响应头
```

三条硬约束（违反即静默失效，不报错）：

1. **一个响应只跑一条 `http-response` 脚本。** 规则是「第一条 pattern 匹配且已启用的生效」，后面的不再执行。所以**同一 URL 不要写两条脚本**——要合并成一个脚本内部 `if/else`。
2. **Body Rewrite 先于 Script。** 同时写了 `http-response-jq` 和脚本时，脚本看到的是 jq 改过的 body。想拿原始 body，就把 jq 规则删掉。
3. **Map Local 命中后不再请求上游。** 对同一 URL 同时写 `[Map Local]` 和 `[Script]`，两者的相对行为不保证跨版本一致——**不要这么写**。

> 推论：三端都适用同一条原则——**同一 URL 只保留一条处理链**。需要多个改动时，在一个脚本内完成，而不是加第二条规则。

**Loon**：同一 phase 内按**配置顺序**执行（不是按"优先级"），来源优先级 **本地配置 > 插件**。新旧语法可混用，仍按书写顺序。所以插件规则可能被用户本地配置"盖住"——排障时先问一句「你是不是另外配过」。

**QuanX**：`[rewrite_local]` 先于 `[rewrite_remote]`。同一 URL 多条命中时不要依赖顺序，合并成一条。

**多插件抢同一域名**：Surge 看模块启用状态、Loon 看插件列表顺序，本质都是"先命中者生效"。这类冲突极难排查，README 里应当直接写明**「请勿与同类插件同时启用」**——比事后解释便宜得多。

### 6.7 内存与性能预算

`requires-body=true` 不是免费参数：它要把**整个响应体缓冲进内存**。Surge iOS 跑在 Network Extension 里，系统对该扩展的内存有硬限制，超了会被系统直接杀掉——表现是 Surge 突然断开，而不是弹一条报错。这也是"规则写对了却偶发断连"的常见原因。

成本直觉（数量级，用于建立判断，不是精确值）：

| 项 | 成本 |
|---|---|
| 单个 5MB 响应的 `requires-body` | 约 10–15MB 峰值（原始 + 解压 + UTF-8 字符串） |
| 三个脚本同时命中大接口 | 叠加，极易触顶 |
| `binary-body-mode=true` | 跳过 UTF-8 解码，二进制场景更省 |
| `debug=true` | 每次从磁盘重载脚本 + 记录日志，**生产环境必须关闭** |

**调优顺序**（从最有效到最无效）：

1. **收窄 pattern** —— 收益最大。`^https?://api\.x\.com/v1/feed/list$` 比 `^https?://` 省两个数量级
2. **设 `max-size`** —— 只给真正需要的接口开大；不需要 body 的一律 `requires-body=false`
3. **`binary-body-mode`** —— 仅图片 / protobuf 场景
4. 最后才考虑拆脚本、换引擎

**反模式**（看到就按 bug 处理）：

```ini
# ✗ 全站缓冲，必然拖垮客户端
demoapp = type=http-response,pattern=^https?://.*,requires-body=true,max-size=-1,script-path=...
```

```ini
# ✓ 精确到接口，只给这一个接口开 body
demoapp-feed = type=http-response,pattern=^https?://api\.demoapp\.com/v1/feed/list$,requires-body=true,max-size=2097152,script-path=...
```

**另一个容易忽略的上限**：`[Body Rewrite]` 处理响应体在 iOS 上只到 1MB（macOS 10MB），超出则**放弃改写、原样透传**；请求体上限 32MB，且 `Transfer-Encoding: chunked` 或 `Expect: 100-continue` 时不支持请求体改写。这些全都**不报错**，只体现为「没生效」——所以 §9 清单里把 `max-size` 单列了一条。

---

## 7. 脚本骨架（一份脚本服务三端）

```js
/**
 * <appname>-<场景>.js
 * 适用：<AppName> <版本号>
 * 用途：<一句话说明改什么、为什么>
 * 兼容：Surge 5.x / Loon 3.x / Quantumult X 1.4.x
 */
(function () {
  'use strict';

  /* ---------- 三端适配层（只用到共同子集时可整段删掉） ---------- */
  const ENV = typeof $task !== 'undefined' ? 'qx'
            : (typeof $loon !== 'undefined' ? 'loon' : 'surge');

  function notify(title, subtitle, body) {
    try {
      if (ENV === 'qx') $notify(title, subtitle, body);
      else $notification.post(title, subtitle, body);
    } catch (e) { /* 通知失败不影响主流程 */ }
  }

  /* ---------- 业务逻辑 ---------- */
  function transform(body) {
    let obj;
    try {
      obj = JSON.parse(body);
    } catch (e) {
      return null;            // 解析失败 → 交给调用方原样放行
    }

    if (!obj || typeof obj !== 'object') return null;

    // ← 在这里做最小必要改动
    // 例：删除数组中的推广项
    const data = obj.data;
    if (data && Array.isArray(data.items)) {
      data.items = data.items.filter(function (it) {
        if (!it || typeof it !== 'object') return true;
        const t = String(it.type || '').toLowerCase();
        return !(t === 'ad' || t === 'promote' || it.is_ad === true);
      });
    }

    return obj;
  }

  function main() {
    const body = $response && $response.body;

    // 分支一：无 body（204/304/被 max-size 截断）→ 原样放行
    if (!body) return $done({});

    const out = transform(body);

    // 分支二：解析失败 → 原样放行，绝不返回空 body
    if (out === null) return $done({});

    return $done({ body: JSON.stringify(out) });
  }

  main();
})();
```


**骨架里每个 `return` 都是一道防线：**

| 分支 | 若不这样写会怎样 |
|---|---|
| `if (!body) return $done({})` | 对 204 响应强行返回 body → 连接中断，App 报网络错误 |
| `JSON.parse` 失败返回 `null` | 抛异常 → 不调 `$done` → 请求挂起直到超时（5 秒），页面白屏 |
| 改动前判断 `Array.isArray` | 接口改版后 `.filter is not a function` → 同上 |

### 7.1 幂等性：改两次必须等于改一次

脚本可能被重复执行：客户端重试、用户下拉刷新、你在客户端里手动重放。**基于「状态」的写法天然幂等，基于「增量」的写法会累积。**

| 写法 | 幂等 | 原因 |
|---|---|---|
| `obj.enable = false` | ✅ | 设置目标状态 |
| `obj.items = obj.items.filter(...)` | ✅ | 从原始数据推导，不依赖上次结果 |
| `obj.count--` | ❌ | 每跑一次少一 |
| `obj.items.push(x)` | ❌ | 每跑一次多一条 |
| `obj.list.splice(0, 1)` | ❌ | 位置依赖，二次执行删错对象 |

本地自检（不需要装插件，10 秒）：

```js
// idem.js — 用法: node idem.js <脚本.js> <样本body.json>
const fs = require('fs');
const script = fs.readFileSync(process.argv[2], 'utf8');
const body = fs.readFileSync(process.argv[3], 'utf8');

function run(input) {
  let out;
  new Function('$response', '$done', script)({ status: 200, headers: {}, body: input }, o => { out = o; });
  return out.body !== undefined ? out.body : input;   // $done({}) 视为原样放行
}
const once = run(body);
console.log(once === run(once) ? '✅ 幂等' : '❌ 二次执行结果不同');
```

两条真实输出：

```
$ node idem.js demoapp-feed.js feed.json
✅ 幂等

$ node idem.js bad.js feed.json        # 脚本里写了 interval = interval - 1
❌ 二次执行结果不同
```

> 这个测试还能抓出一类隐蔽事故：脚本先 `JSON.parse` 再 `JSON.stringify`，**键顺序发生变化**，导致第二次输出与第一次字节不同。多数客户端不在意，但带签名的接口会因此校验失败。

### 7.2 缓存污染：改完 body，关掉插件反而更糟

这是 body 改写独有的副作用，也是「插件关了广告还在」的头号原因。

App 收到改写后的响应，会**写入本地数据库或磁盘缓存**。于是：

- 关闭插件 → App 仍展示旧缓存 → 用户认为「插件关不掉」
- 服务端下发正常数据 → 与本地脏数据打架 → 空白、重复、错位

| 表现 | 成因 | 处置 |
|---|---|---|
| 关插件后广告还在 | 素材已落盘（本地缓存目录） | 清缓存 / 重装 |
| 关插件后界面错乱 | 缓存里存了 `banner: null`，而展示逻辑假设非空 | 清缓存；规则改为"置空数组"而非 `null` |
| 开插件后白屏 | 改写后的结构与客户端预期不符 | 回退该条，改用"保留结构、清空内容" |

**由此得出一条设计原则**（比 §15.7 更具体）：

> **优先改「服务端开关」，少改「客户端展示态」。**
> `splash.enable = false` 是让 App 自己决定不展示，撤掉规则后一切复原；
> `banner = null` 是硬塞给客户端一个它没预期的状态，撤掉后可能留下脏数据。

交付强制项：凡是改 body 的规则，README「停用」一节必须写 **「停用后建议清除 App 缓存或重装」**。不写，用户就会把缓存问题当成插件 bug。

### 7.3 分页游标：删数组元素最阴的坑

信息流接口常是 `items` + `cursor` / `next_page_token` 结构，而这个 **cursor 是服务端按「完整列表」算出来的**。

删掉广告项之后：

- 客户端拿旧 cursor 请求下一页 → 服务端从"第 N 条"继续 → 中间**跳过**正常内容
- 或客户端按 index 渲染 → 删掉第 3 条后，第 4 条的缓存 key 错位 → **内容重复**
- 少数 App 会做列表长度校验 → 删项后判定数据异常 → **停止加载**

三种写法，风险递减：

| 写法 | 做法 | 风险 | 适用 |
|---|---|---|---|
| 物理删除 | `items.filter(...)` | 分页错乱、内容重复 | 游标基于 id（如 `last_id`）且服务端不校验长度 |
| 原地降级 | 保留元素，`type` 改成 `post`，内容清空 | 出现空白卡片 | 客户端按 index 渲染，无法容忍长度变化 |
| 字段置空 | 保留元素与结构，只清 `title` / `img` 等展示字段 | 可能有空壳占位 | **默认先试这一种** |

验证方法（必做，30 秒）：

1. 打开列表 → 下滑翻 3 页 → 记住每页首尾内容
2. 检查三件事：有无重复条目？翻页后是否跳回上面？滑到底部能否继续加载？
3. 任一现象出现 → 从「物理删除」退到「字段置空」

> 补 §11 示例 A 没讲透的地方：`filter` 是**最干净**的写法，但不是**最安全**的写法。在分页场景下，干净和安全是冲突的。

### 7.4 流式响应不能改 body

SSE（`text/event-stream`）、WebSocket 升级响应、长轮询：这些响应**没有「完整 body」这个概念**，body 是持续产出的。

后果：`requires-body=true` 会让客户端等一个永远不会结束的 body。表现是**页面一直转圈、消息不刷新**，而日志里一条错误都没有。

| 线索 | 含义 |
|---|---|
| `content-type: text/event-stream` | SSE，直接排除 body 改写 |
| `time` 极大（数万 ms）且 `size` 为 -1 | 长连接 |
| `response.status == 101` | WebSocket 升级 |
| `transfer-encoding: chunked` 且无 `content-length` | 分块流，谨慎处理 |

处置：

- 只做**请求侧**动作（改 header、加参数、整请求拒绝）
- 需要阻断时用 `reject`，不要用 body 改写
- 内容必须在客户端侧处理 → 明确超出本 Skill 范围，如实告知，不要硬做

---

## 8. 输出规范

### 8.1 目录与命名

```
<AppName>-AdBlock/
├── Surge/<AppName>.AdBlock.sgmodule
├── Loon/<AppName>.AdBlock.plugin
├── QuanX/<AppName>.AdBlock.conf
├── scripts/<appname>-<场景>.js
└── README.md
```

- `<AppName>` 用英文/拼音，不用中文和空格（避免客户端安装 URL 编码问题）
- `<场景>` 用 `feed` / `splash` / `float` / `track` 这类短词
- 一个 App 有多个场景时，脚本可拆多个，但**一个客户端只出一个插件文件**，内部用注释分段
- 需要长期维护的，另建 `review/<日期>-<appver>/` 存各版 HAR 与 `rules.txt`（见 §15.4）

### 8.2 README 模板

```markdown
# <AppName> 去广告

## 适用版本
- App：<AppName> <版本号>（<Build>）
- Surge：iOS 5.9.1+ / Loon：3.5.1(983)+ / QuanX：1.4.0+
- 生成日期：<YYYY-MM-DD>
- 语法依据：<官方文档 URL>

## 拦截清单
| 请求 | 手段 | 证据（HAR 命中条数） | 语法级别 | 验证状态 |
|---|---|---|---|---|
| api.demoapp.com/v1/feed/list | 脚本删数组推广项 | 3 | A | 已按 5.14 文档核对 |
| conf.demoapp.com/v2/launch/config | jq 关开关 | 1 | A | 需 iOS 5.14.0+，未在用户版本实测 |
| img.demoapp.com/splash/ | Map Local tiny-gif | 2 | C | 社区通行写法，未实测 |

> 语法级别填 A/B/C（定义见 SKILL.md §13.2）。**非 A 级必须同时给出失效预案。**

## 失效预案
| 若这条失效 | 改用 |
|---|---|
| jq 改写不生效（客户端版本不足） | `[Script]` + demoapp-launch.js |
| `[Map Local]` tiny-gif 不认 | `[URL Rewrite] ^re _ reject`（注意可能触发客户端重试或降级到备用源） |
| 脚本被 max-size 截断 | 调大 max-size 或改为只处理响应头 |

## 安装
### Surge
1. 把 .sgmodule 放到 iCloud/Surge 目录，或上传后「模块 → 安装新模块」
2. 确认「MitM」已开启且根证书已信任

### Loon
1. 插件 → + → 从 URL 安装 / 导入本地 .plugin
2. 确认该插件已启用，MitM 已开启

### QuanX
1. 把 [rewrite_local] 与 [mitm] 两段追加到配置文件对应位置
2. 脚本文件放到 `Scripts/` 目录（若用本地路径）

## 停用
- Surge / Loon：关掉模块开关即可
- QuanX：注释掉 [rewrite_local] 里对应行

## 失效自查
1. MitM 是否绿锁？红锁 = 证书或 hostname 问题
2. pattern 是否还命中？重新抓包跑 `jq ... test($re)`
3. App 是否升版？升版后字段/路径变更需重新生成
```

### 8.3 验证闭环：让用户三步自证生效

交付后最常见的对话是「装了没效果」。给一条可执行的自证路径，比让用户「描述一下现象」有效得多。

**第一步：看客户端自己的信号**

| 端 | 在哪看 | 正常表现 | 异常含义 |
|---|---|---|---|
| Surge | Dashboard → 该请求的 Notes | 出现脚本名；`debug=true` 时还有 `console.log` 输出 | 无脚本名 = pattern 没命中 |
| Loon | 请求记录里的脚本 tag | 显示配置的 tag | 无 tag = 未命中 |
| QuanX | 请求列表的重写图标 | 🔒 绿锁 = MitM 成功；✏️ 红笔 = 重写生效 | 🔴 红锁 = **MitM 失败** |

QuanX 的红锁是「装了没反应」的头号原因，九成是证书没信任或 hostname 没加，不是规则问题。

**第二步：抓包看 body 是否真的变了**

重开抓包 → 触发广告 → 看该请求的响应体。已经变过 → 说明规则生效，问题在客户端展示层（回 §7.2 查缓存）。

**第三步：分层定位（顺序不能跳）**

```
图标 / 日志都没有         → MITM 层：hostname 覆盖了吗？证书信任了吗？
有图标但 body 没变        → pattern 层：正则精确吗？回 §5.7 复验
body 变了但界面没变       → 客户端层：读了缓存（§7.2），或改的字段不是渲染源
body 变了、界面也变了、广告仍在 → 多点驱动（§15.5 第三行）
```

跳过任何一层，都会在错误的位置改规则——这是最常见的返工原因。

**Surge 的两个诊断线索**（都写在官方 MITM 文档里）：

- **证书固定（pinning）**：如果客户端完成 TLS 握手后**没发请求就断开**，Surge 会在日志里提示该域名很可能启用了 pinning。这种情况下规则永远不可能生效，只能放弃该域名并如实说明。
- **HTTP/3 绕过**：App 走 QUIC 时 MITM 可能压根不生效。Surge 的 `auto-quic-block` 默认开启（iOS 5.8.0+），会自动阻断命中 MITM 列表的 QUIC 连接，让客户端回退到 HTTP/2。若用户手动关过这个开关，表现就是「部分请求抓不到」。

### 8.4 隐私脱敏：HAR 是高敏文件

一份 HAR 通常含有 `Cookie`、`Authorization`、手机号、设备标识、地理位置、甚至通讯录片段。这些**绝不能进交付物**。

| 位置 | 风险 | 做法 |
|---|---|---|
| 插件文件注释 | 贴了真实 token | 只写字段名，不写值 |
| README 示例 body | 含真实用户数据 | 用 `<TOKEN>` / `u_123456` 占位 |
| 截图 | 状态栏、账号头像、手机号 | 打码后再贴 |
| 规则正则 | 用真实 token 做匹配 | 只匹配结构（路径、字段名），不匹配凭证 |
| 报错 / 日志回显 | 整段 body 打出来 | 只回显长度与字段名 |

**默认动作**：分析在本地做，只把「结构」带进交付物。

> 这也是 §11 / §12 里所有域名都写成 `demoapp.com`、所有 body 都是虚构的原因：**示例可以通用，真实抓包不行。**

---

## 9. 自检清单

交付前逐条打勾，不过不许交付。

**证据类**
- [ ] 每条 pattern 都在 HAR 上跑过 `test($re)`，命中数 > 0
- [ ] 每个「广告字段」都有实际 body 样本佐证，不是靠字段名猜
- [ ] 删改的字段不影响同一响应中的业务字段（已对照完整 body 检查）
- [ ] 跑过 §5.10 完整性校验：所有要改的条目 `content.text` 不为 null、未截断
- [ ] 开屏类已用 §5.9 时序确认为「链」（配置 → 下发 → 素材），不是单点
- [ ] 隐藏类需求已出「隐藏范围清单」并经用户确认（§17.2）
- [ ] 已用全局字段搜索（§17.3）确认所有渲染面，不是只改了列表接口

**语法类**
- [ ] 段名大小写正确：`[MITM]` / `[Mitm]` / `[mitm]`
- [ ] 动作关键字拼写正确：`reject-img`（QX/Loon 旧）vs `reject_img()`（Loon 新）
- [ ] 正则中的 `.` `?` `+` `(` `)` 已按需转义；`?` 在 URL 查询串里必须写成 `\?`
- [ ] 三端 pattern 逐字符一致
- [ ] 每条非 A 级写法（文档查不到但有实例）都在 README 标了 C 级 + 来源 + 验证状态
- [ ] 承担主逻辑的 C 级写法都有对应「失效预案」，且预案是可直接替换的完整写法，不是一句「改用脚本」
- [ ] **没有一条是无实例硬造的关键字**（自查方法：逐条问「这条我在哪见过」，答不出具体仓库/页面的，删掉）

**MITM 类**
- [ ] hostname 覆盖所有 pattern 的 host（含子域通配）
- [ ] 没有把不支持 MITM 的域名塞进去（会造成该域名访问失败）
- [ ] 不需要 MITM 的纯 reject 域名，也放进了 hostname（HTTPS reject 同样需要 MITM）

**运行时类**
- [ ] `requires-body=true`（Surge）或 `requires-body=true`（Loon）或 `script-response-body`（QX）已声明
- [ ] `max-size` 足够：Surge 默认 1MB(iOS)，信息流接口常超，建议显式写 `max-size=2097152`
- [ ] 脚本所有分支都调 `$done`，无抛出路径
- [ ] 没有手写 `Content-Length`（三端都会自动重算）
- [ ] 脚本幂等：`node idem.js` 输出 ✅（§7.1）
- [ ] 未对 `text/event-stream`、`status 101`、长连接开 `requires-body`（§7.4）
- [ ] 删数组元素前已翻页验证：无重复、无跳回、能继续加载（§7.3）
- [ ] 同一 URL 只有一条处理链：没有两条 `http-response` 脚本，没有 `[Map Local]` + `[Script]` 并存（§6.6）
- [ ] 没有 `pattern=^https?://.*` 配 `requires-body` 的组合（§6.7）
- [ ] 覆盖矩阵里每条渲染面都有对应规则，没有「知道了但没做」的条目（§17.4）

**交付类**
- [ ] 版本号写进了插件注释与 README
- [ ] README 含安装、停用、自查三节
- [ ] 「失效自查」按 §8.3 的四层顺序写，不是一句「重启试试」
- [ ] 改 body 的规则已在「停用」节标注「建议清除 App 缓存」（§7.2）
- [ ] 已脱敏：交付物里无真实 token / Cookie / 手机号 / 设备号（§8.4）
- [ ] 隐藏类需求附「覆盖矩阵」与「未实现项及原因」两张表（§17.6）
- [ ] 验收清单已覆盖正向 / 反向 / 跨端三组（§17.5）
- [ ] 说明了已知失效风险

---

## 10. 失效陷阱

按出现频率排序，每条都是真实踩过的坑。

| # | 陷阱 | 现象 | 处置 |
|---|---|---|---|
| 1 | 只拦素材不拦配置 | 开屏依然有，只是变白/灰块 | 配置与素材必须同时处理 |
| 2 | 只拦配置不拦素材 | 素材已缓存，广告照播 | 同上；必要时清 App 缓存 |
| 3 | 用 `DOMAIN-SUFFIX` 拦主域 | 图片/推送/统计全挂 | 只在证据显示是独立广告域时使用 |
| 4 | MITM 漏了子域 | 规则不生效，日志无记录 | 用 `*.demoapp.com` 而非逐个枚举 |
| 5 | 正则未转义 `.` | 命中一堆无关 URL，误伤 | 每个 `.` 写 `\\.`；用 §5.7 验证 |
| 6 | 响应体超 `max-size` | 大接口静默跳过脚本 | 显式调大 `max-size` |
| 7 | 在脚本里自己 gunzip | 拿到乱码 | 三端交付的都是解压后的字符串，别再解 |
| 8 | 手改 `Content-Length` | 响应截断 / 客户端解析失败 | 不写，交给客户端 |
| 9 | `$done` 漏调 | 请求挂起 5 秒后超时 | 骨架保证全分支 `$done` |
| 10 | 硬取嵌套字段 | 接口改版后整页白屏 | `(a && a.b) \|\| []` 防御式取值 |
| 11 | QX `hostname = *` | 全量 MITM，性能崩、证书报错 | 精确到域名 |
| 12 | Loon 用了新语法但版本不够 | 插件加载但规则不生效 | 旧语法或写 `#!loon_version` |
| 13 | Surge 用 jq Body Rewrite 但版本不够 | 无任何提示，规则被忽略 | 加 `#!requirement` |
| 14 | 抓包时没存 body | 所有改写方案失效 | 重抓（Step 0 已拦） |
| 15 | `[Body Rewrite]` 的 jq 表达式写错 | 只留一条 warning，规则被静默跳过 | 先在本地 `jq -c '<表达式>' sample.json` 跑通，再贴进插件 |
| 16 | 以为 `#!requirement` 覆盖了所有新特性 | `CORE_VERSION>=20` 写对了，jq 仍不生效 | `20` 只到 iOS 5.10.0，jq 要 5.14.0+；版本要求另写进 README（见 §2.3） |

---

## 11. 示例 A：信息流数组型广告（必须写脚本）

### 场景

`DemoApp 7.12.0` 首页信息流。抓包发现 `https://api.demoapp.com/v1/feed/list` 返回：

```json
{
  "code": 0,
  "data": {
    "items": [
      { "id": "a1", "type": "post", "title": "正常内容" },
      { "id": "a2", "type": "ad", "ad_id": 8821, "title": "推广：xxx" },
      { "id": "a3", "type": "promote", "title": "推广卡片" }
    ],
    "banner": { "img": "https://img.demoapp.com/b/1.jpg", "link": "https://adx.demoapp.com/c" },
    "ad_config": { "enable": true, "interval": 5 }
  }
}
```

### 为什么必须写脚本

注意 `items` 是数组，广告是「数组里 `type == ad/promote` 的元素」。
- Surge 的 `http-response-jq` 能做，但需要 iOS 5.14+
- Loon 的 `response.json.delete` 只能删固定键路径（如 `data.banner`），**无法按条件过滤数组元素**
- QuanX 没有原生 JSON 动作

所以：**一份脚本，三端共用**，一致性最好。

### Step 1 取证

```bash
# 找到索引
jq -r '.log.entries | to_entries[]
  | select(.value.request.url | test("feed/list")) | "\(.key)"' target.har
# 假设是 12，导出 body
jq -r '.log.entries[12].response.content.text' target.har > feed.json
# 确认广告标记位（用与 §5.5 相同的兼容写法，避免 fromjson 报错）
jq -r '(if type=="string" then fromjson else . end)
  | [.. | objects | .type? // empty] | group_by(.) | map({v:.[0], n:length})' feed.json
```


命中：3 条 `feed/list`，`type` 取值分布为 `post`×N、`ad`×2、`promote`×1。

### Step 2 脚本

```js
/**
 * demoapp-feed.js
 * 适用：DemoApp 7.12.0
 * 用途：过滤信息流推广项、关闭顶部 banner 与广告轮插配置
 */
(function () {
  'use strict';

  const AD_TYPES = ['ad', 'promote', 'sponsor'];

  function main() {
    const body = $response && $response.body;
    if (!body) return $done({});

    let obj;
    try { obj = JSON.parse(body); } catch (e) { return $done({}); }
    if (!obj || typeof obj !== 'object' || !obj.data) return $done({});

    const data = obj.data;

    // 1) 过滤数组中的推广项
    if (Array.isArray(data.items)) {
      data.items = data.items.filter(function (it) {
        if (!it || typeof it !== 'object') return true;
        const t = String(it.type || '').toLowerCase();
        return AD_TYPES.indexOf(t) === -1 && it.is_ad !== true;
      });
    }

    // 2) 清空顶部 banner（保留键，避免客户端 key 缺失报错）
    if (data.banner) data.banner = null;

    // 3) 关闭广告轮插
    if (data.ad_config && typeof data.ad_config === 'object') {
      data.ad_config.enable = false;
    }

    return $done({ body: JSON.stringify(obj) });
  }

  main();
})();
```

注意第 2 步：**把 `banner` 置 `null` 而不是 `delete data.banner`**。删除键会让部分客户端因「字段缺失」抛异常或走兜底兜出更差的布局；置 `null` 是兼容性更好的做法。

> 但这与 §7.2 存在一个取舍：`null` 会被客户端写进缓存，停用规则后可能留下脏数据（表现为关插件后界面错乱）。若你复现了这个现象，把这一行改成置空数组 `data.banner = {}` 或按客户端预期给一个空结构，而不是 `null`。**先按 `null` 交付，出问题再降级**——这个顺序比反过来省事。

### Step 3 三端插件

**Surge** `Surge/DemoApp.AdBlock.sgmodule`

```ini
#!name=DemoApp 去广告
#!desc=移除信息流推广项与顶部 banner；适配 DemoApp 7.12.0
#!system=ios
#!category=去广告
#!requirement=CORE_VERSION>=20

[Script]
demoapp-feed = type=http-response,pattern=^https?://api\.demoapp\.com/v1/feed/list,requires-body=true,max-size=2097152,script-path=https://cdn.example.com/scripts/demoapp-feed.js

[MITM]
hostname = %APPEND% api.demoapp.com
```

**Loon** `Loon/DemoApp.AdBlock.plugin`

```ini
#!name = DemoApp 去广告
#!desc = 移除信息流推广项与顶部 banner；适配 DemoApp 7.12.0
#!tag = 去广告
#!system = iOS
#!date = 2026-11-01

[Script]
http-response ^https?://api\.demoapp\.com/v1/feed/list script-path=https://cdn.example.com/scripts/demoapp-feed.js, requires-body=true, tag=信息流去广告, enable=true

[Mitm]
hostname = api.demoapp.com
```

**QuanX** `QuanX/DemoApp.AdBlock.conf`

```ini
[rewrite_local]
^https?://api\.demoapp\.com/v1/feed/list url script-response-body https://cdn.example.com/scripts/demoapp-feed.js

[mitm]
hostname = api.demoapp.com
```

### 附：Surge 无脚本备选（iOS 5.14.0+）

用户没有脚本托管地址时，用 jq 一次到底：

```ini
[Body Rewrite]
http-response-jq ^https?://api\.demoapp\.com/v1/feed/list '.data.banner = null | .data.ad_config.enable = false | .data.items |= map(select(((.type // "") | test("^(ad|promote|sponsor)$") | not) and (.is_ad != true)))'
```

这条 jq 表达式与上面的 JS 逻辑等价，可对照阅读——**同一个改动意图，两种表达**。能用这条就不用脚本。

---

## 12. 示例 B：开屏广告（声明式即可，不必写脚本）

### 场景

`DemoApp 9.3.0` 启动开屏。抓包发现由**三部分**驱动：

| 请求 | 响应 | 作用 |
|---|---|---|
| `https://conf.demoapp.com/v2/launch/config` | `{"splash":{"enable":true,"duration":5}}` | 开关：是否展示 |
| `https://splash.demoapp.com/v1/get?slot=open` | `{"ad_id":11,"img":"...","click":"..."}` | 广告数据下发 |
| `https://img.demoapp.com/splash/0912.jpg` | `image/jpeg` | 素材 |

### 为什么这个场景不该写脚本

三处都是「固定键」或「整请求」，没有任何「按条件过滤集合」的需求。
- 改开关 → 一个键路径
- 拦素材 → 一个动作
- 拦广告接口 → 一个动作

**全是声明式能覆盖的。** 此时写脚本，等于给自己多加一个托管依赖和三个失效点。

### 关键判断：为什么不能整域拒绝

`img.demoapp.com` 同时服务头像、封面图、表情。对它有 `DOMAIN-SUFFIX,...,REJECT` 会让整个 App 变灰。
`conf.demoapp.com` 同时服务版本检查、灰度开关。拦了整个域，App 起不来。

→ **只能路径级拦截，且素材用 Mock 不用 reject。**

### 三端插件

**Surge**

```ini
#!name=DemoApp 开屏去广告
#!desc=关闭开屏配置开关 + 拦截开屏素材；适配 DemoApp 9.3.0
#!system=ios
#!category=去广告
#!requirement=CORE_VERSION>=20

[Body Rewrite]
http-response-jq ^https?://conf\.demoapp\.com/v2/launch/config '.splash.enable = false'

[URL Rewrite]
^https?://splash\.demoapp\.com/v1/get _ reject

[Map Local]
^https?://img\.demoapp\.com/splash/ data-type=tiny-gif

[MITM]
hostname = %APPEND% conf.demoapp.com, splash.demoapp.com, img.demoapp.com
```

> ⚠️ **注意上面这行 `#!requirement` 挡不住版本问题。** `CORE_VERSION>=20` 只对应「Body Rewrite 自 iOS 5.10.0 起可用」，而 **jq 改写要 iOS 5.14.0+，中间没有可表达的 CORE_VERSION 档位**（详见 §2.3）。
> 所以 jq 方案必须做到二者之一：① 在 README 的「适用版本」里显式写 `Surge iOS 5.14.0+`；② 干脆改用 `[Script]` + `demoapp-launch.js`，一次绕开版本门槛。
> 不要以为加了 `#!requirement` 就安全了——旧版本上的表现是**规则被静默忽略**，没有任何报错。

**Loon**

```ini
#!name = DemoApp 开屏去广告
#!desc = 关闭开屏配置开关 + 拦截开屏素材；适配 DemoApp 9.3.0
#!tag = 去广告
#!system = iOS
#!loon_version = 3.5.1(983)

[Rewrite]
response if ${url} ~= /^https?:\/\/conf\.demoapp\.com\/v2\/launch\/config/ && ${response.status} == 200 then response.json.replace("splash.enable", false)

request if ${url} ~= /^https?:\/\/splash\.demoapp\.com\/v1\/get/ then reject_dict(200)

request if ${url} ~= /^https?:\/\/img\.demoapp\.com\/splash\// then reject_img(200)

[Mitm]
hostname = conf.demoapp.com, splash.demoapp.com, img.demoapp.com
```

> 注意 `reject_dict(200)` 用于 `splash/v1/get`：返回 `{}` 比返回 404 更安全——App 拿到空对象会判定「无广告」，而 404 可能触发重试或降级到备用源。
>
> Loon 低版本（< 3.5.1(983)）改用旧语法：
> ```ini
> [Rewrite]
> ^https?://splash\.demoapp\.com/v1/get url reject-dict
> ^https?://img\.demoapp\.com/splash/ url reject-img
> ```
> 旧语法没有 JSON 动作，`config` 接口需改用脚本。

**QuanX**

```ini
[rewrite_local]
^https?://conf\.demoapp\.com/v2/launch/config url response-body "splash"\s*:\s*\{\s*"enable"\s*:\s*true response-body "splash":{"enable":false
^https?://splash\.demoapp\.com/v1/get url reject-dict
^https?://img\.demoapp\.com/splash/ url reject-img

[mitm]
hostname = conf.demoapp.com, splash.demoapp.com, img.demoapp.com
```

> QuanX 的 `response-body` 是**正则替换**，对 JSON 的空格/字段顺序敏感。`\s*` 是为了容忍不同序列化风格。如果该接口的 body 是压缩成一行的（常见），这条能稳定工作；如果字段顺序变了（`{"enable":true,"splash":...}`），就需要调整正则或退回脚本。

### 两个示例的对照，是这套方法的核心

| | 示例 A | 示例 B |
|---|---|---|
| 广告形态 | 数组里的元素 | 固定开关 + 独立资源 |
| 能否声明式 | 不能（需按条件过滤集合） | 能（固定键 + 整请求） |
| 脚本 | 必须 | 不必 |
| 主要风险 | 接口字段改版 | 正则对格式敏感 |

**先判断「能不能不写脚本」，再动手写。** 顺序反了，就会产出一堆本可避免的依赖。

---

## 13. 官方文档索引与查阅纪律

> **本 Skill 不存文档快照，一律运行时现查。** 这是刻意的取舍：宁可每次多花一次抓取，也不要拿到一份过期的语法。
> 代价是**断网 / 改版时零兜底**——所以 §6 的内联表是唯一保底，边界见 §6.5。
>
> **索引的用法**：这些链接是**入口**，不是知识。查的时候带着具体问题去（「这个动作叫什么」「这个能力从哪个版本开始」），不要整页通读。
> **链接会腐坏**。路径失效时按 §13.3 的顺序降级，不要把「打不开」当成「这个能力不存在」。
> **核验日期：2026-11-01**。下表路径当天实测可达；`manual.nssurge.com` 改过版，早期教程里的 `/module/`、`/http-processing/url-rewrite.html` 均已 404——这正是不要从记忆抄 URL 的理由。

### 13.1 索引

**Surge**（`manual.nssurge.com`，官方手册，权威度最高）

| 路径（相对 `https://manual.nssurge.com`） | 用途 | 重点看 |
|---|---|---|
| `/profile/module.html` | 模块能改哪些段、元信息、`#!arguments` | 「Write a Module」小节 |
| `/http/url-rewrite.html` | 重定向 / 拒绝 / header 模式 | 三部分格式：正则 + 替换 + 类型 |
| `/http/header-rewrite.html` | 四种 header 动作 | `header-add/del/replace/replace-regex` |
| `/http/map-local.html` | Mock 静态响应 | `data-type` 四种取值与版本门槛 |
| `/http/body-rewrite.html` | 正则 body 改写 + **jq body 改写** | 「JQ Body Rewrite」小节 + 版本号 |
| `/http/mitm.html` | hostname 写法与排除 | `-` 前缀排除、`hostname-disabled`、证书固定（pinning）警告 |
| `/scripting/overview.html` | 七种脚本类型与公共参数 | `pattern` / `requires-body` / `max-size` |
| `/scripting/http-response.html` | `$request` / `$response` / `$done` | 返回值字段与 abort 语义 |
| `/profile/requirement.html` | `CORE_VERSION` 与版本对照 | 「Core Version」小节——**门槛判断的唯一依据** |

**Loon**（`nsloon.app`，官方文档，中英文路径相同，可切语言）

| 路径（相对 `https://nsloon.app`） | 用途 | 重点看 |
|---|---|---|
| `/docs/Plugin` | 插件元信息、`[Argument]`、`[General]`、`[IP Rewrite]` | 开头的完整示例，可整体照抄结构 |
| `/docs/Script/script_v2` | 新 Script 语法（3.5.1(983)+） | 五种脚本类型 + `with` 参数 |
| `/docs/Rewrite/rewrite_v2` | 新 Rewrite 语法 | 动作表 + **新旧映射表**（迁移旧规则必备） |

**Quantumult X**（⚠️ **无官方文档站**，权威度：客户端内置 > 官方仓库 > 社区）

| 来源 | 用途 |
|---|---|
| `https://raw.githubusercontent.com/crossutility/Quantumult-X/master/rewrite.md` | 18 种重写动作的官方样例（header / response-body / script） |
| 同仓库 `sample-rewrite-response-header.js`、`sample-rewrite-with-script.js` | 脚本返回值写法 |
| 客户端内「配置文件 → 编辑」 | 最权威的段名与真实位置 |

### 13.2 权威度分级

| 级别 | 来源 | 处理方式 |
|---|---|---|
| A | Surge 手册、Loon 官方文档 | 直接采信，冲突时以它为准 |
| B | 官方 GitHub 仓库（QX） | 采信，但注意样例可能早于客户端版本 |
| C | 社区可验证写法（如 Surge `#!category`、`#!author`） | **默认保留**，但必须标注 + 备好降级预案 |
| D | 博客 / 论坛 / 二手教程 | 只用来找线索，不直接写进插件 |

#### 文档查不到时：保留还是禁用

本 Skill 的取向是 **默认保留并标注**。社区能跑通的写法，往往比「退化成脚本」更轻、更快、更可读——比如一个 `reject_dict(200)` 就返回了空 JSON，改用脚本实现反而要多托管一个文件、多一个失效点。

但"保留"有前提，不是无条件放行：

| 情况 | 处置 |
|---|---|
| 文档没有，但**有可验证实例**（公开仓库里真实在用的插件、或某版本实测生效） | ✅ 保留。标注 C 级 + 来源 + 验证状态，README 写降级预案 |
| 文档没有，**只在博客见过一次**，无源码可查 | ⚠️ 谨慎保留。先核对语法结构是否自洽；核不了按 D 级处理 |
| 文档没有，**自己照着另一端的语法硬造**（如把 QX 的 `reject-img` 直接改成 Loon 的 `reject-img(200)` 而没确认） | ❌ 禁止。这不叫"社区写法"，这叫幻觉 |
| 保留的写法承担**拦截逻辑的唯一实现** | ⚠️ 保留的同时必须附等价脚本方案，写进「失效预案」 |
| 保留的写法只是**装饰性/增强性**（分类、图标、作者信息） | ✅ 放心保留，失效也不影响功能 |

> 判定口诀：**有实例 = 保留，无实例 = 禁止，扛主逻辑 = 必须留后路。**

### 13.3 链接失效时的降级顺序

1. **换语言/等价页**：Surge 手册有 `/book/understanding-surge/cn/`；Loon 中英文路径同构。
2. **回根域导航**：打开 `https://manual.nssurge.com/` 首页，它有「Capability Map」把功能映射到具体页面。
3. **搜站内**：`site:manual.nssurge.com <关键字>`。
4. **查客户端版本说明**：新特性通常在 release notes 里先出现。
5. **仍找不到官方文档 → 转按 §13.2 的判定表处理**：有可验证实例就保留并标 C 级，没有就禁用、改用脚本。**不要照另一个客户端的语法硬造关键字。**

### 13.4 查阅纪律

1. **写之前必看，不靠记忆。** 三端语法高度相似但关键字不同（`reject-img` / `reject_img(200)` / `[Map Local]`），凭印象写必然出错。
2. **官方文档 > 社区博客 > 自己推断。** 社区写法只用于补「文档没写但确实存在」的场景，并标注级别 C。
3. **看到 build 号就记下来，并且要追到版本映射表。** 「iOS 5.14.0+」只是功能声明，能不能用 `#!requirement` 表达是另一回事——必须去 `/profile/requirement.html` 查 Core Version 档位（这一条 §2.3 已用血泪教训写明）。
4. **查不到 ≠ 不存在 ≠ 可以乱写。** 先找可验证实例：有实例按 C 级保留并标注，无实例一律禁止硬造（判定表见 §13.2）。
5. **交付时注明依据。** README 的「语法依据」一栏填实际查阅的文档 URL + 核验日期——方便日后 API 变更时定位。
6. **读页面要带问题。** 整页抓下来会被导航和无关小节淹没；抓取时明确「我要 X 动作的语法」比「总结这个页面」有效得多。

### 13.5 运行时抓取规程

既然不存快照，**抓取质量就等于语法质量**。按以下八条执行：

| # | 规程 | 为什么 |
|---|---|---|
| 1 | **只抓三类片段**：动作关键词、参数表、示例块 | 整页摘要会丢掉决定成败的拼写细节 |
| 2 | **提问要具体**：「X 客户端 X 动作的准确写法与参数顺序」，而不是「总结这个页面」 | 前者能拿到可粘贴的语法，后者拿到的是概述 |
| 3 | **同页只抓一次**：把该页要确认的 3~5 个问题合并成一次请求 | 省轮次，也避免同一页不同次抓取结论不一致 |
| 4 | **先版本，后语法**：先确认页面的版本门槛，再确认拼写 | 顺序反了会写出「语法正确、版本不够、静默失效」的规则 |
| 5 | **交叉验证取具体页**：同一能力出现在概览页与专题页时，以专题页为准 | 概览页倾向简化，容易漏参数 |
| 6 | **失败只重试 1 次**（换语言版或根域导航），仍失败就按 §13.3 降级 | 反复重试同一死链是纯浪费，结论不会变 |
| 7 | **禁止用记忆补全**：降级后仍无法确认的语法，写成「待验证」而不是写成一个猜测 | 一个错关键字 = 一份不生效的插件 |
| 8 | **记录出处**：抓到的页面 URL + 日期写进 README「语法依据」 | 日后客户端或文档变更时可快速定位 |

**时效性判断**：若页面上的 build 号比用户客户端更新，说明它描述的是新版行为。此时以**用户版本**为准做取舍，并在 README 提示「升级到 X 后本插件行为可能变化」——这正是"随时最新"必须付出的对价：文档永远领先于用户，不能直接照抄。

---


## 14. 边界

**做**：拦截广告展示、推广卡片、开屏物料、曝光/点击埋点、追踪 SDK 上报。

**不做**：
- 绕过会员、订阅、付费墙、授权校验（改 `is_vip` / `expire_time` / 订单状态这类字段）
- 修改风控、实名、定位等与广告无关的业务字段
- 生成针对特定商业实体的定向干扰规则
- 在用户未提供 HAR 的情况下凭 App 名称「猜」接口

遇到用户要求前者时：说明本 Skill 只处理广告与追踪流量，建议改抓广告相关请求。**这不是能力限制，是交付质量标准**——改业务字段产生的规则，一次接口升级就会把用户数据改坏。

---

## 15. 复核与维护（C 级规则的定期体检）

### 15.1 为什么维护要单独成一节

生成一次，失效无声。三端对无法解析的行处理方式不同，但**共同点是不报错**：

- **Surge**：无效 hostname 只进 warning；`#!requirement` 不满足时整行视为未启用
- **Loon**：参数或类型错误会导致**整行被拒绝加载**，插件其余部分照常工作
- **QuanX**：正则或动作解析失败，跳过该行

结果都一样：**插件还在、开关还是绿的、广告回来了。** 唯一可靠的信号是用户看见广告——而那时候已经晚了。

所以维护不是"出事再查"，而是**交付时就把每条规则写成可复核的**。

### 15.2 给规则编号（交付时就要做）

插件文件里，每条规则上方加 ID 注释：

```ini
# [S1] A级 · 依赖 data.items[].type · 失效信号：广告卡片重现
demoapp-feed = type=http-response,pattern=^https?://api\.demoapp\.com/v1/feed/list,requires-body=true,script-path=...
```

```ini
# [L1] A级 · 旧语法 · 依赖 /v1/feed/list
http-response ^https?://api\.demoapp\.com/v1/feed/list script-path=..., requires-body=true
```

```ini
; [Q1] C级 · reject-dict（文档未载，社区通行）· 失效预案：改用 reject(204)
^https?://splash\.demoapp\.com/v1/get url reject-dict
```

README 里维护总表：

| ID | 规则 | 级别 | 依赖什么 | 失效信号 | 复核方法 |
|---|---|---|---|---|---|
| S1 | feed 脚本删推广项 | A | 字段 `data.items[].type` | 广告卡片重现 | 重抓后跑 §15.4 脚本 + 比对 body |
| S2 | jq 关开屏开关 | A | 键路径 `splash.enable` | 开屏照常弹出 | 导出 body 看键是否改名 |
| S3 | Map Local tiny-gif | C | `data-type=tiny-gif` 是否被支持 | 开屏出现灰块 | 客户端升级后优先测这条 |

> 这张表是维护的全部依据。没有它，三个月后连你自己也说不清当初为什么这么写。

### 15.3 三个触发时机

| 时机 | 频率 | 做什么 |
|---|---|---|
| **App 升级** | 最高频 | 全量复核（§15.4），重点看 pattern 是否还命中 |
| **客户端升级** | 中 | 只测 C 级 + 版本门槛相关条目（不必重抓 HAR） |
| **广告重新出现** | 被动 | 从「失效信号」列反查是哪一条挂了 |

### 15.4 复核流程（App 升级后，约 10 分钟）

**Step 1 建基线目录**（下次对比时省事）

```bash
mkdir -p review/$(date +%F)-<appver>
```

**Step 2 按 §2.1 的口径重抓一轮 HAR**（只做「打开 App → 触发广告 → 关闭」）

**Step 3 跑体检脚本**。先把 §15.2 表里的 ID + 正则抄成 `rules.txt`，一行一条：

```
# ID 正则
S1 ^https?://api\.demoapp\.com/v1/feed/list
S2 ^https?://conf\.demoapp\.com/v2/launch/config
S3 ^https?://img\.demoapp\.com/splash/
```

```bash
#!/usr/bin/env bash
# check-rules.sh <new.har> <rules.txt>
set -u
HAR="${1:?usage: check-rules.sh <new.har> <rules.txt>}"
RULES="${2:?usage: check-rules.sh <new.har> <rules.txt>}"
[ -r "$HAR" ] || { echo "✗ 读不到 HAR: $HAR"; exit 1; }
[ -r "$RULES" ] || { echo "✗ 读不到规则表: $RULES"; exit 1; }

total=0; miss=0
while read -r id re || [ -n "${id:-}" ]; do
  case "$id" in ''|\#*) continue ;; esac
  [ -z "${re:-}" ] && continue
  total=$((total+1))
  n=$(jq --arg re "$re" '[.log.entries[] | select(.request.url | test($re))] | length' "$HAR" 2>/dev/null || echo ERR)
  if [ "$n" = "ERR" ]; then
    echo "! $id  正则语法错误  ← $re"; miss=$((miss+1))
  elif [ "$n" -eq 0 ]; then
    echo "✗ $id  命中 0  ← 可疑失效: $re"; miss=$((miss+1))
  else
    echo "✓ $id  命中 $n"
  fi
done < "$RULES"
echo "----"; echo "共 $total 条，可疑 $miss 条"
```

实测输出（含一条失效、一条正则写错的情形）：

```
✓ S1  命中 1
✓ S2  命中 1
✓ S3  命中 1
✗ S4  命中 0  ← 可疑失效: ^https?://api\.demoapp\.com/v1/old_gone
! S5  正则语法错误  ← ^https?://(unclosed
----
共 5 条，可疑 2 条
```

**Step 4 命中 ≠ 有效。** 命中只证明「接口还在」，不证明「字段还在」。
- 对 `✗` 的条目 → 走 §15.5 归因
- 对 `✓` 的条目 → 至少抽 1 条导出 body 复核字段（§5.4 → §5.5）

**Step 5 更新记录**：README「验证状态」列改为 `已复核 <日期> / <App 版本>`。

### 15.5 失效归因：四种情况，四种处置

| 体检结果 | 判断 | 处置 |
|---|---|---|
| pattern 命中 0 | App 换了接口 | 回 §3 Step 1 重新画像，**不是去改正则** |
| pattern 命中，广告还在 | 字段改名 / 结构变了 | 导出 body 比对（§5.4 → §5.5），改脚本里的键路径 |
| pattern 命中、body 也对，广告仍在 | **多点驱动**（配置 + 素材 + 预热缓存） | 补拦另一处，参考 §12 的三处联动 |
| 只有 C 级条目失效（客户端升级后） | 该写法不被新版本识别 | 用 README「失效预案」替换；该条降级为 D，改用 A 级实现 |

第三种最容易误判成「脚本有 bug」。判断方法：**二分法**——先全关插件确认广告恢复，再只开一半规则，逐层定位是哪一层没拦住。

### 15.6 维护节奏

| 频率 | 动作 | 耗时 |
|---|---|---|
| App 每次升级 | §15.4 全量复核 | ~10 分钟 |
| 客户端每次升级 | 只测 C 级 + 版本门槛条目 | ~2 分钟 |
| 每季度 | 打开 §13.1 的链接，确认仍可访问 | ~3 分钟 |
| 每年 | 清理已下架 / 已改版的 App 规则 | — |

### 15.7 反直觉的结论：越巧的规则，坏得越快

规则的条件越多、脚本越复杂，失效概率越高——因为它依赖的字段、路径、时序假设也越多。

所以维护成本应该**反过来约束设计**：

- 一条规则需要每版都修 → 说明它拦在了错误的位置
- **往上找比往下修耐用**：改配置开关（`splash.enable`）比改渲染结果（隐藏某个 View）稳定一个数量级
- 一行 `reject` 能表达的，就不要用二十行脚本

> 判断标准：如果一条规则让你每版都得动，那它是技术债，不是功能。

---

## 16. 规则索引（跨 App 的项目记忆）

### 16.1 为什么它是独立文件

§13 说「不存文档快照」，但索引不是快照，两者性质相反：

| | 文档快照 | 规则索引 |
|---|---|---|
| 内容来源 | 别人的页面 | 你自己的产出 |
| 时间方向 | 会过期 | 只会增长 |
| 失效方式 | 改版即失效 | 不失效，只是变旧 |

所以索引独立成 `registry.md`，**不写进本文档**——否则每加一个 App 都在改 skill 本体，skill 升级时还会被覆盖。

> 分工：**SKILL.md 定义协议，registry.md 存数据。** 前者是代码，后者是状态。

### 16.2 文件位置与结构

默认与 SKILL.md 同级（`./registry.md`）。若插件库在别处（如 `~/AdBlockPlugins/`），把索引放插件库根目录，并在文件头改 `location:` 一行。

四段结构：

```
索引表（App / Bundle ID / 适配版本 / 插件目录 / 规则数 / 上次复核 / 状态）
└─ 按 App 分节
   ├─ 元信息（Bundle ID、别名、插件目录、上次复核、已知坑）
   ├─ 规则表（ID / 规则 / 级别 / 依赖 / 失效信号 / 状态）
   └─ 历史（版本 / 日期 / 变更）
```

**两个字段决定这个索引好不好用**：

- **别名**：用户不会说 `com.demo.app`，只会说"那个蓝色的购物 App"。别名列就是给他用的
- **失效信号**：必须是**用户能看见的现象**（"信息流里又出现推广卡片"），不能是技术描述（"字段不匹配"）。写错了，反查时对不上号

### 16.3 三个写入时机

| 时机 | 写什么 | 成本 |
|---|---|---|
| 首次交付某 App | 新建一节，规则表**直接从 §15.2 的总表搬过来** | 几乎为零（本来就写过一遍） |
| 每次复核后 | 更新「上次复核」+ 状态列 + 追加历史一行 | 1 分钟 |
| 规则废弃 / App 下架 | **不删除**，标 `⛔ 已废弃` + 日期 | 10 秒 |

> 「不删除」是刻意的：废弃记录的价值在于**下次遇到同一个 App 时，知道上次为什么放弃**。删掉就等于允许自己重踩一遍。

### 16.4 反查协议：用户说「X 又有广告了」

**Step 1 定位**

```bash
grep -n -A 4 -i "<关键词>" registry.md | head -40
```

按 App 名、Bundle ID、别名三列模糊匹配。匹配到多条时向用户确认一句（只问一次）。

**Step 2 分支**

| 情况 | 处置 |
|---|---|
| 索引里有，版本一致 | 直接进 Step 3 |
| 索引里有，但 App 已升级 | 先跑 §15.4 体检，再进 Step 3 |
| 索引里没有 | 走完整流程 §3；交付后补写索引 |

**Step 3 两问定向**（最多两问，多问就是浪费用户时间）

1. **「广告还在原来那个位置，还是换了新位置？」** → 前者=旧规则失效，后者=新增广告位
2. **「只有这个 App，还是其他 App 也这样？」** → 后者大概率是客户端/MITM 层问题，不是规则问题

**Step 4 给归因**（按这个格式回，用户才看得懂）

```
【归因】DemoApp 7.13.0 · 信息流推广卡片
- 对应规则：S1（A级，依赖 data.items[].type）
- 索引记录：上次复核 7.12.0，该条失效信号=「信息流重新出现推广卡片」→ 吻合
- 判断：旧规则失效，大概率是标记字段改名（type → card_type）
- 下一步：重抓 feed/list → §5.10 完整性校验 → 导出 body 看 items 里的标记字段名
- 预计：10 分钟
```

四个要素缺一不可：**对应哪条 ID、依据是什么、判断成哪一类、下一步做什么**。只说"可能是接口变了"等于没说。

**Step 5 回写**

处理完更新状态列 + 复核日期；如果是新坑，写进「已知坑」——这是索引持续增值的唯一方式。

### 16.5 区分两类「又有广告」（索引最大的价值）

| 特征 | 旧规则失效 | 新增广告位 |
|---|---|---|
| 位置 | 和以前一样 | 页面里多了一块 |
| 索引的「失效信号」列 | 对得上号 | 不适用 |
| 处置 | 改正则 / 改字段，更新同一条规则 | **新增规则 ID**，走 §3 重新画像 |
| 耗时 | 通常 10 分钟 | 可能改变整体技术路线 |

**误判代价不对称**：把「新增位置」当成「旧规则失效」处理，会一直去改一条本来没问题的规则，越改越乱，最后连原来的效果都丢了。索引的作用就是把这两类在动手前分开。

### 16.6 防膨胀

| 情况 | 处置 |
|---|---|
| 超过 12 个月未复核 | 状态标 `🕒 stale`，下次用到前先全量复核 |
| App 已下架 / 完全不兼容 | 标 `⛔ 已废弃`，规则表折叠成一行摘要 |
| 索引表超 20 行 | 拆成「活跃 / 归档」两张表 |

> 一条边界：**索引只记录「当时为什么这么写」，不记录「现在应该怎么改」。** 后者属于插件文件与本文档，混进来会让这份记忆变成第二个真相源，两边打架时没人说得清哪边对。

---

## 17. 界面裁剪：需求边界与验收标准

### 17.1 为什么「可实现就必须实现」要立成硬规则

用户提的是「我看不见这个东西」，不是「我在这个页面看不见这个东西」。这两句话的差别，就是覆盖度。

半覆盖的代价链条是这样的：

```
改了一个渲染面 → 用户切换页面又看见 → 「你不是说好了吗」
→ 信任打折 → 重新抓包、重新定界、重新验收 → 成本翻倍
```

所以覆盖度不是「尽力而为」，而是一条可判定的规则：

> **要么把范围枚举完并全部实现，要么明确说出哪一项做不到、为什么。**
> 中间状态（做了一部分、没说其余）是唯一不可接受的交付。

这条规则也解释了为什么 §0 把它列为第四条核心原则：**它约束的不是技术，是交付态度。**

### 17.2 需求定界：三问 + 一份清单

隐藏类需求在写任何规则之前，必须问完这三个问题。每个问题都对应一个会翻车的分支：

**问 1：隐藏入口，还是关闭功能？**

| 用户答 | 处置 | 答错的后果 |
|---|---|---|
| 只是不想看见按钮 | 只裁剪渲染数据 | — |
| 整个功能都不想要 | 除了裁剪，还要考虑深链 / 推送 / 搜索结果入口 | 入口没了但功能还能进，用户认为没做好 |

> 判断线索：如果这个功能有独立页面、能被推送或分享链接唤起，那它就不只是一个按钮。

**问 2：「范围」包含哪些渲染面？**

同一字段通常出现在列表、详情、搜索、个人中心、推送落地页、设置页。逐项跟用户确认，**不要替他决定"应该只要列表就行"**。

**问 3：该区域留白、塌陷重排、还是占位替代？**

- 留白 → 可能被用户当成 bug
- 塌陷重排 → 布局变化大，但视觉最干净
- 占位替代（灰条/提示） → 最稳，但用户可能觉得没去掉

不问这一条就去删元素，最常见的结果是页面中间空一块，用户回来问"为什么有块空白"。

**产出物：隐藏范围清单**（交付前必须让用户确认，一张表说清全部）

| # | 界面位置 | 入口形态 | 触发接口 | 判据字段 | 处置手段 | 在范围内 |
|---|---|---|---|---|---|---|
| 1 | 首页信息流卡片右上角 | 「推广」标签 | `/v1/feed/list` | `items[].type == "ad"` | 脚本过滤 | ✅ |
| 2 | 首页顶部横幅 | 整条 banner | `/v1/feed/list` | `data.banner` | 置空 | ✅ |
| 3 | 搜索页结果 | 同款推广卡片 | `/v1/search` | `items[].type == "ad"` | 脚本过滤 | ✅ |
| 4 | 推送落地页 | 底部悬浮按钮 | `/v1/push/landing` | `show_cta` | 置 false | ✅ |
| 5 | 我的 → 会员入口 | 列表项 | `/v2/user/center` | `modules[].key == "vip"` | 过滤数组 | ⚠️ 待用户确认 |

最后一列是这张表的灵魂：**明确写清哪些在范围内、哪些待确认**。没有这一列，后面所有争论都无从对账。

### 17.3 一个字段有多个渲染面：怎么找全

这是「覆盖完整」的技术核心。同一业务字段通常出现在四类位置：

| 类型 | 典型样子 | 找法 |
|---|---|---|
| 列表接口 | `/feed/list` 里的 `item.type` | §5.2 关键词 + §5.5 键路径 |
| 详情接口 | `/feed/detail?id=` 里的同名字段 | **全局搜字段名**（下条命令） |
| 配置接口 | `/config` 里的 `show_xxx: true` | 优先处理：可逆、覆盖面最大 |
| 本地缓存 / 冷启动下发 | Tab 配置、开屏配置 | §5.9 时序；清缓存前后各抓一次对比 |

**全局搜字段名**——这一条命令决定你的覆盖矩阵完整不完整：

```bash
jq -r --arg f 'show_cta' '.log.entries[]
  | select((.response.content.text // "") | test($f))
  | [.request.url, (.response.content.mimeType // "-")] | @tsv' target.har | sort -u
```

实测输出：

```
https://conf.demoapp.com/v2/launch/config	application/json
https://splash.demoapp.com/v1/get?slot=open	application/json
```

同一个字段命中两个接口 → 覆盖矩阵就该有两行。只改一处，等于没改。

**三个漏检陷阱**（这条命令本身也会漏）：

| 陷阱 | 表现 | 补救 |
|---|---|---|
| `text == null` 的条目搜不到 | 某些接口明明有该字段却没出现在结果里 | 先跑 §5.10，把缺 body 的补齐再搜 |
| `base64` 编码的响应搜不到 | 命中数比预期少 | 对该条目先解码再搜（§5.4） |
| 客户端已缓存的字段不经过网络 | 改完仍显示 | 清缓存后重抓，确认该字段是否还有网络来源 |

第二条尤其坑：**搜索是纯文本匹配，它看不见压缩/编码后的内容。** 命令给你的是下限，不是全集。

### 17.4 判定表：必须实现 / 不做 / 不可实现

「凡技术上可实现必须一并实现」需要一张判定表来落地，否则会被"这个比较麻烦"糊过去。

| 情形 | 结论 | 说明 |
|---|---|---|
| 同一字段出现在多个接口 | **必须全部覆盖** | 少一处 = 用户切页面又看见 |
| 存在服务端开关字段 | **必须优先关开关** | 可逆、无缓存污染，撤规则即复原 |
| 只能改渲染数据 | 必须做 | 并在 README 注明缓存副作用（§7.2） |
| 有 A/B 实验或灰度，返回结构有两种 | **必须同时覆盖两条分支** | 只处理一种，等于对一半用户无效 |
| 需要改 protobuf / 加密 body | 不可实现 | 明确说明；给替代方案（外层容器字段、配置开关） |
| 界面是原生硬编码，无网络交互 | 不可实现 | 明确说明，**不要假装修好了** |
| 隐藏会破坏主流程（支付、登录、实名） | 不做 | 说明风险，让用户书面确认后再定 |

> **「不做」只有两种合法理由：技术上不可实现，或会破坏主流程。**
> 除此之外一律必须实现——"要写脚本""比较麻烦""估计用户不会去那个页面"都不算理由。

### 17.5 验收标准：写成可观察的清单

三条硬要求：**可观察**（不是"应该好了"）、**可复现**（换台设备照样行）、**含反向项**（确认没弄坏别的）。

**A. 正向 —— 该消失的都消失了**

- [ ] 列表页不再出现该入口
- [ ] 详情页不再出现该入口
- [ ] 搜索结果里不再出现该内容
- [ ] 个人中心 / 设置页不再出现该入口
- [ ] 推送落地页 / 深链进入后不出现该入口（仅当问 1 答"关闭功能"时）
- [ ] 冷启动（清缓存后）不出现
- [ ] 未登录 / 新注册账号下不出现（有些模块按登录态下发）

**B. 反向 —— 不该坏的都没坏**

- [ ] 相邻功能可正常点击，无"点了没反应"
- [ ] 列表翻页、下拉刷新正常（§7.3）
- [ ] 布局无异常空白 / 塌陷（截图对照）
- [ ] 该区域周边交互（跳转、点赞、分享）不报错

**C. 跨端一致**

- [ ] Surge / Loon / QuanX 三端表现一致（pattern 逐字相同）
- [ ] 关闭插件后恢复原状（**前提：已清缓存**，否则回不到原样）

> B 组最容易被跳过，也最容易出事故。**只验 A 组，等于只验了一半**——用户要的是"这个没了、其他照旧"，不是"这个没了，页面也废了"。

### 17.6 交付必须附的两张表

1. **覆盖矩阵**：字段 × 接口 × 界面位置 × 处置手段
2. **未实现项及原因**：做不到的、主动放弃的，各写一句理由

> 这两张表是"完整覆盖"的唯一证据。没有它们，用户无法区分「你漏了」和「你做不到」——而这两种在他眼里是一样的。

同时把覆盖矩阵摘要写进 §16 索引的 App 条目（新增字段 `裁剪范围`），下次这个 App 再提同类需求时可直接复用，不必重新枚举。

### 17.7 裁剪类专属翻车方式

| 现象 | 根因 | 预防 |
|---|---|---|
| 用户说「这里还有」 | 只改了列表接口，详情/搜索没改 | §17.3 全局搜字段 |
| 入口没了但功能还能进 | 只隐藏入口，未判断是否需要拦路由 | §17.2 问 1 |
| 隐藏后页面空一块 | 直接删元素、未与用户确认重排 | §17.2 问 3 |
| 关插件后仍不恢复 | 字段改动被客户端缓存 | §7.2 清缓存 |
| 新版又出现 | 改的是展示层，根在服务端开关 | 优先改开关（§17.4 第 2 行） |
| 一半用户有效、一半没效 | A/B 灰度两条返回结构只覆盖了一条 | §17.4 第 4 行 |
| 用户觉得"你只做了一半" | 没交覆盖矩阵与未实现清单 | §17.6 |

---

## 18. 快速回顾

真到动手时，只需记住这个顺序：

1. **要版本号 + HAR**（缺一个就停）
2. **先分清是「去广告」还是「界面裁剪」**（§3 Step 0.5）；裁剪类必须**先出隐藏范围清单并经用户确认**（§17.2），没有清单不动手
3. **jq 收敛到 3~8 条候选，并校验数据完整**（§5.1 → §5.10；开屏类先跑 §5.9 时序）
4. **裁剪类：全局搜字段找全渲染面**（§17.3），一个字段命中几个接口，覆盖矩阵就有几行
5. **每条候选标一个手段**（§4 决策树）
6. **先问「能不能不写脚本」**（§12）
7. **查文档核语法**（§13，按 §13.5 现查，先版本后语法；查不到但有实例的按 §13.2 保留并标注）
8. **三端 pattern 逐字一致**
9. **过一遍自检清单**（§9），尤其幂等（§7.1）与翻页验证（§7.3）——这两条只能靠实测
10. **交付时讲清证据、手段、风险**；裁剪类另附覆盖矩阵与未实现项（§17.6）
11. **给每条规则编号 + 写维护清单**（§15.2），否则三个月后无法复核
12. **回写索引**（§16.3），同一个 App 第二次来找你时，这条能省掉一半时间

三处最容易搞砸的，按重要性排：

- **「能不能不写脚本」**这一步，决定了你交出去的是一个「装了就忘」的插件，还是一个「三天后要用户传文件」的半成品
- **「隐藏范围清单」**这一步，决定了用户会不会在下一个页面撞见同一块东西，然后说「你不是说好了吗」
- **「规则编号 + 回写索引」**这两步，决定了你在这批 App 上投入的时间是随数量线性增长，还是随经验递减
